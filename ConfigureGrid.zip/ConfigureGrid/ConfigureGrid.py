import tkinter as tk
def ConfigureGrid(widget, row_number, column_number, pad_y_number):
    widget.grid(row=row_number, column=column_number, pady=pad_y_number)