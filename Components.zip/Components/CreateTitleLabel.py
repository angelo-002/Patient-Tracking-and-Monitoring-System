import tkinter as tk


def CreateTitleLabel(frame, title_text="Login", font=None, title_text_color="black"):
    if font is None:
        font = ("Roboto", 20, 'bold')

    title_label = tk.Label(frame, text=title_text, fg=title_text_color, font=font)
    return title_label