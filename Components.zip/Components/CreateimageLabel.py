import tkinter as tk


def CreateImageLabel(frame, icon):
    label = tk.Label(frame, image=icon, )
    return label
